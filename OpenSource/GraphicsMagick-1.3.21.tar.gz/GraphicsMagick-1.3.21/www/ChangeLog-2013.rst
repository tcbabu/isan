2013-12-31  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - version.sh: Update for 1.3.19 release.

  - www/index.rst: Update for 1.3.19 release.

  - NEWS.txt: Update for 1.3.19 release.

  - magick/blob.c (GetBlobTemporary): Add assertions to assure that
    image and blob are valid structures.

  - coders/png.c (ReadOnePNGImage): Fix problem peculiar to Q8 build
    with reading 1-bit PNG files.

  - PerlMagick/t/png/(write-16.t, read.t, write-16.t, write.t):
    Update expected signatures

  - coders/xpm.c (WriteXPMImage): Limit XPM color resolution to what
    XPM can traditionally handle.

  - magick/enhance.c (GammaImage): Eliminate a compiler warning.

  - coders/png.c (ReadOnePNGImage): Eliminate a compiler warning.

  - coders/pcl.c (WritePCLImage): Eliminate a compiler warning.

2013-12-29  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/delegate.c (InvokePostscriptDelegate): Log return status.

  - magick/nt\_base.c (NTGhostscriptFonts): For Microsoft Windows,
    also search c:\gs\fonts for Ghostscript font files.

  - coders/ept.c (ReadEPTImage): Fix crash observed when Ghostscript
    fails to produce output.

2013-12-28  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/annotate.c: Simplify FreeType2 header inclusion.

  - configure.ac: Only test for freetype/freetype.h if ft2build.h
    was not found.

2013-12-24  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - ttf: Update FreeType to release 2.5.2.

  - Updated build to use Automake 1.14.1.

2013-12-23  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - libxml: Update libxml2 to release 2.9.1.

2013-12-22  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - lcms/include/lcms2.h: Update lcms to release 2.5.

  - png/README: Update PNG library to release 1.6.8.

  - jpeg: Update Windows IJG JPEG library to release 9.

2013-12-20  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/alpha\_composite.h (BlendCompositePixel): Fix from Troy
    Patteson to eliminate induced color problems when compositing two
    images which include fully transparent pixels.  Now fully
    transparent pixels do not contribute any color to the composed
    result. Opacity used when blending is now based on the average
    opacity of both pixels.  Resolves SourceForge issue #148 "Pixel
    interpolation problem with rotated transparent images ".

2013-12-18  Glenn Randers-Pehrson  <glennrp@simple.dallas.tx.us>

  - coders/png.c (ReadOnePNGImage): Properly scale 16-bit input
    PNG down to 8-bit when using a Q8 build.

2013-12-15  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - Magick++/demo/piddle.cpp (main): Use DrawableDashArray to make
    sure that it works.

  - wand/drawing\_wand.c (DrawSetStrokeDashArray): Fix defective
    stroke-dasharray MVG generation.  Resolves SourceForge issue "#255
    DrawSetStrokeDashArray still fails".

  - magick/draw.c (DrawSetStrokeDashArray): Fix defective
    stroke-dasharray MVG generation.

2013-12-02  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/jpeg.c: Add value scaling changes which will be necessary
    to support all the build depths supported by IJG JPEG 9a.

  - coders/webp.c (ReadWEBPImage): Support 'ping'. Improve quality
    of error reporting.

  - GraphicsMagick.spec.in: Update RPM spec file to add
    libwebp-devel as a build dependency, and libwebp as a run-time
    depdendency.

2013-12-01  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/webp.c: Incorporated simple WebP support as contributed
    by "TIMEBUG" at users.sf.net plus a few security changes. Does not
    yet support Windows Visual Studio build, input from a pipe,
    attached profiles, animation, or incremental pixel I/O.
    (RegisterWEBPImage): Register WebP as requiring seekable stream so
    input from pipe works.

2013-11-30  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - wand/drawing\_wand.c (DrawSetStrokeDashArray): Use array size
    specified by user and don't expect user-provided array to be
    terminated by 0.0.  Resolves SourceForge bug "#250 Unexpected
    results from DrawSetStrokeDashArray".

  - magick/draw.c (DrawSetStrokeDashArray): Use array size specified
    by user and don't expect user-provided array to be terminated by
    0.0.

  - wand/drawing\_wand.c (DrawGetStrokeDashArray): terminating 0.0 to
    array returned to user.

  - magick/draw.c (DrawGetStrokeDashArray): Add terminating 0.0 to
    array returned to user.

2013-11-24  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/annotate.c (RenderFreetype): Support rendering UTF-8
    21-bit code points.  Was limited to 16-bit code points due to an
    oversight/bug.  Resolves SourceForge bug "#149 Rendering UTF-8
    encoded file displays wrong glyphs".

2013-11-21  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/constitute.c (ReadImage): Consistently initialize Image
    page width and height to image width and height. Resolves
    SourceForge bug #253 convert pdf output page is the wrong size
    with -geometry "100%".

2013-11-18  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/tiff.c (WriteTIFFImage): TIFFDefaultStripSize() sometimes
    returns zero so make sure that rows-per-strip is at least one to
    avoid divide by zero error.  This bug was added in the current
    development cycle.

2013-10-26  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - NEWS.txt: Update news since last release.

  - magick/annotate.c (RenderFreetype): Support Johab, Latin-1, and
    Latin-2 encodings.

2013-10-22  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - wand/drawing\_wand.c (DrawSetStrokeLineJoin): BevelJoin should
    produce MVG text "bevel".

  - magick/draw.c (DrawSetStrokeLineJoin): BevelJoin should produce
    MVG text "bevel".  Fixes SourceForge bug "#245 error occured to
    DrawableStrokeLineJoin(LineJoin.BevelJoin)".

2013-10-16  Glenn Randers-Pehrson  <glennrp@simple.dallas.tx.us>

  - Added calls to png\_set\_benign\_errors() to allow benign errors
    to be handled as warnings.  In particular, GM builds with libpng-1.6.x
    will not crash while copying a PNG with a "known incorrect ICC
    profile".

2013-10-08  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/nt\_base.c (NTGhostscriptEXE): Use gswin64c.exe as
    Ghostscript executable name in a 64-bit application.

2013-10-06  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/nt\_base.c (NTGhostscriptFind): 64-bit application should
    not search for Ghostscript in 32-bit registry.  SourceForge bug
    #243 "GM on Windows will find Ghostscript only if both are 32 bit"

2013-09-28  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/pnm.c: As an extension to the standard PNM and PAM
    formats, support writing 32-bit sample depth in the Q32 build, and
    supporting reading 32-bit sample depth in all builds.

2013-09-22  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/tiff.c: Allow reading signed integer TIFF files even
    though internal storage uses signed integers.  Negative values
    will be handled incorrectly and positive values will be scaled to
    only 1/2 of the available unsigned range.  Perhaps the situation
    will improve in the future.

  - tests/rwfile\_miff.tap: Test MIFF with specific depths.

  - tests/rwblob.c: Add support for -quality option.

  - tests/rwfile.c: Add support for -quality option.

  - tests/rwfile.tap: Add tests for PGM and PPM ASCII subformats.

  - coders/pnm.c (WritePNMImage): PGM "P2" format writer was broken
    at 8-bit depth due to lack of white-space between the output
    values.  Fixed now.

2013-09-21  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/miff.c (ReadMIFFImage): Fixes to be able to read MIFF
    written by ImageMagick 6.X, including DirectClass grayscale
    images.  Interoperabilty is not completely assured since
    ImageMagick is not consistent with itself and may only be able to
    read the file it just wrote.  Reading DirectClass grayscale RLE
    compressed images is not supported yet.

2013-09-16  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/profile.c (MagickFreeCMSTransform): Only delete the CMS
    transform if it is non-null.  If lcms returned a null transform,
    an assertion was thrown in lcms when the pointer was freed.
    Problem was reported by James Bardin.

2013-09-08  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/miff.c: PseudoClass format was written incorrectly in
    that sample storage size is supposed to be selected based on the
    size of the colormap, but it was being selected based on the depth
    parameter instead, leading to excessively sized files and failure
    to read what was written.  RLE compressed formats had the sense of
    the alpha channel inverted from the other compression methods, and
    contrary to the specification.  PseudoClass with Alpha was not
    supported at all, and reading a file claiming to be such caused an
    assertion to be thrown.  Note that these fixes may cause some
    existing files to no longer be read correctly.

  - coders/xpm.c (ReadXPMImage): XPM is rarely used to produce
    16-bit output.  Set image depth based on the colormap.

  - coders/tim.c (ReadTIMImage): PSX TIM is not able to produce more
    than 8-bit output, set image depth appropriately.

2013-09-04  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/tiff.c (WriteTIFFImage): Increase rows-per-strip as
    required to try to avoid more than 32K strips per image since some
    programs seem to use a 16-bit strip counter and fail with more
    than 32K strips.  Problem was reported by Kevin Myers.

  - magick/transform.c (MosaicImages): Fix unsigned underflow
    problem with -mosaic when page offset is negative and exceeds
    image width or height.  This problem caused assertions, out of
    memory errors, or pixel cache limit errors due to requesting an
    image of outrageous size.

2013-08-26  Jaroslav Fojtik  <JaFojtik@seznam.cz>
        \* dcraw\dcraw.c Updated from autor
        \* dcraw\dcraw.c.patch

2013-08-25  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/pnm.c (ReadPNMImage): Fix SourceForge issue #237
    "Incorrect MAXVAL scaling when reading PAM images".

2013-08-10  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/render.c (DrawImage): Improve error handling so that
    rendering bails on image access/update errors.  Resolves
    SourceForge issues #233 "Another SVG that hangs GraphicsMagick"
    and #232 "Another SVG that hangs GraphicsMagick".  The resolution
    of the bug is to return from image access/update error right away
    rather than adjusting the rendering density to produce a smaller
    image.

  - magick/error.h: Hide exception throwing convenience macros under
    MAGICK\_IMPLEMENTATION definition.

  - Magick++/demo/demos.tap: Fix file naming for 'zoom' demos.

  - magick/annotate.c (RenderFreetype): Improve error handling so
    that rendering bails on image access/update errors.

2013-08-02  Glenn Randers-Pehrson  <glennrp@simple.dallas.tx.us>

  - coders/png.c (ReadOnePNGImage): ping a png faster by
    returning the image without reading the pixel data.

2013-07-20  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/xwindow.c (MagickXMakeImage): Only use ThumbnailImage()
    for DirectClass images in order to avoid a crash while creating
    the panner image.

2013-04-28  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - design/pixel-cache-struct.dot: Update structure relationships
    diagram.

  - design/pixel-cache.dot: Update call flow diagram.

  - magick/pixel\_cache.c: Eliminate use of internal functions
    GetNexusIndexes(), GetNexusPixels().  Reduce usage of internal
    function IsNexusInCore().

2013-04-20  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - configure.ac: MAGICK\_SSIZE\_T should always be a signed type.

  - coders/jpeg.c (WriteXMPProfile): Add support for writing 'XMP'
    profile in JPEG.
    (WriteJPEGImage): Restructure/tidy JPEG profile writing code.

2013-04-16  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/tiff.c (ReadTIFFImage): Return DirectClass images by
    default for MINISWHITE and MINISBLACK TIFF formats.

2013-04-07  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/wpg.c, magick/attribute.c, magick/map.c, magick/render.c,
    magick/widget.c, magick/xwindow.c: Fixes to reduce warnings with
    GCC 4.8.0 at -O3 optimimization level, and for clang 3.2.

2013-04-03  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/xwindow.c (MagickXMakeImage): Use ThumbnailImage() rather
    than SampleImage() when creating the panner image to improve the
    quality of the image.

2013-03-31  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/attribute.c (tag\_table): Add support for SubjectArea EXIF
    tag.  Resolves SourceForge issue #229 "Cannot Parse the
    SubjectArea EXIF Info".

2013-03-27  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - www/Hg.rst, www/index.rst: Update SourceForge Mercurial
    repository location (see
    http://hg.code.sf.net/p/graphicsmagick/code) due to project
    "upgrade".  For the moment there are old and new
    repositories. Changes will be pushed to the new repository.

2013-03-25  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/resource.c (InitializeMagickResources): Revert use of
    omp\_set\_dynamic() since it caused a severe performance regression
    when doing a -stepthreads benchmark or when the number of OpenMP
    threads is set via OMP\_NUM\_THREADS.

2013-03-17  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - INSTALL-unix.txt: Add a section about building Windows binaries
    by cross-compiling from a Unix/Linux system.

2013-03-16  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - configure.ac, magick/magick\_types.h.in: Fix issues noticed when
    cross-compiling with MinGW64.

2013-03-09  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - version.sh, www/index.rst: Prepare for 1.3.18 release.

2013-03-04  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/command.c (DisplayImageCommand): display is supposed to
    respond to +/-usePixmap, but was not.  It was responding to
    +/-use\_pixmap.  Now it responds to both.

2013-03-03  Glenn Randers-Pehrson  <glennrp@simple.dallas.tx.us>

  - doc/GraphicsMagick.imdoc: Relocated some <im> .. </im> tags, to
    include several paragraphs that were omitted from the
    GraphicsMagick man page (Environment, Configuration Files, and
    Copyright).

  - doc/imdoc2man: the </pre> tag was being deleted instead of
    replaced with nothing, which caused the first line of the
    subsequent material to be joined to the last line of the <pre>
    block.

2013-03-02  Glenn Randers-Pehrson  <glennrp@simple.dallas.tx.us>

  - coders/png.c (ReadOnePNGImage): Avoid a libpng16 warning about
    storing unknown chunks.

2013-02-25  Glenn Randers-Pehrson  <glennrp@simple.dallas.tx.us>

  - coders/png.c (WriteOnePNGImage): Call png\_set\_bKGD(), etc.,
    after png\_set\_IHDR() because they depend on members of info\_ptr
    which are set by png\_set\_IHDR().

2013-02-20  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/resource.c (InitializeMagickResources): Enable the
    dynamic adjustment of OpenMP threads if there is more than one
    thread available.

2013-02-18  Glenn Randers-Pehrson  <glennrp@simple.dallas.tx.us>

  - configure.ac and configure: Check for libpng17 and libpng16.

2013-02-13  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - www/programming.rst: Add mention of Clement Farabet's Lua
    scripting language wrapper for GraphicsMagick.

2013-02-10  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/pixel\_cache.c (GetCacheNexus): Re-write function so it
    has a single point of return.
    (AcquireCacheNexus): Reduce the number of return points.
    (SetCacheNexus): Re-write function so it has a single point of
    return.

2013-02-02  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - NEWS.txt: Update with latest news.

  - magick/export.c (ExportAlphaQuantumType): Fix export of alpha
    for RGBA image and depth 8.  Due to typo, was exporting 16-bits
    rather than 8, causing output corruption or crashes.  Resolves
    issue reported in SourceForge GraphicsMagick forum under title
    "CMYK per-channel byte order TIFF crashes gm".

2013-02-01  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/studio.h (MagickIsBlank): Add macro to substitute for ISO
    C99 isblank() which is not globally available.  Update 'gm batch'
    code which had substituted isspace() for isblank() to use it.

2013-01-31  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/command.c (BatchCommand): Flush stdout at key points in
    order to ensure that user sees text when it is produced.

2013-01-30  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/random.c (InitializeMagickRandomGenerator): Use
    MagickTsdKeyCreate2() in order to avoid a small memory leak.

  - magick/tsd.c (MagickTsdKeyCreate2): New private function to
    support allocating a thread-specific data key with a specified
    destructor function.  For single-threaded build, MagickTsdKey\_t is
    now type void\* and there is provision to support the destructor
    function.

2013-01-29  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/command.c (BatchCommand): New 'gm batch' command to
    accept one or more GraphicsMagick commands from a specified text
    file, standard input, or CLI.  Feature is implemented by Kenneth
    Xu.  Submitted via SourceForge Patch #3602331 "Add interactive or
    batch mode support to 1.3.17".

2013-01-27  Glenn Randers-Pehrson  <glennrp@simple.dallas.tx.us>

  - coders/png.c (WriteOnePNGImage): Added PNG48 and PNG64 support.
    Added PNG00 support (png encoder that inherits its color-type and
    bit-depth from the input, if the input was a PNG datastream).

2013-01-26  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/png.c (WriteOnePNGImage): PNG8 support was using
    image->colors to decide if the input image is PseudoClass.  This
    is totally bogus.  Use image->storage\_class to determine if image
    is PseudoClass and quantize image colors if it is not.

  - magick/delegate.c (InvokePostscriptDelegate): Only invoke
    MagickSpawnVP() if Ghostscript filename argument is non-empty.
    This argument may be empty if Ghostscript is not found on a
    Windows system.  Report a "Failed to find Ghostscript" error if
    the Ghostscript command name is empty. Resolves SourceForge issue
    #3601816 "Win64 build crashes trying to convert PDF to any other
    format".

  - magick/utility.c (MagickSpawnVP): Verify that file argument is
    non-NULL and not empty.

2013-01-15  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - VisualMagick/tiff/LIBRARY.txt: Fix pre-processor definitions for
    libtiff so that they use multiple statements rather than one long
    statement.  Resolves SourceForge issue 3601001 "libtiff won't
    compile with ICL".

2013-01-06  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/memory.h (MagickAllocateAlignedArray): New macro to wrap
    use of MagickMallocAlignedArray().

  - magick/memory.c (MagickMallocAlignedArray): New private function
    to support safe allocation of an array in memory with a specified
    alignment.  Allocation may only be freed using MagickFreeAligned()
    and the allocation may not be reallocated.

2013-01-05  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/{animate.c,display.c,utility.c}: Only invoke chdir() if
    path is not an empty string.  Previously sometimes chdir() was
    passed an empty string (because chdir() was not needed) and this
    was ok because we ignored the error status.  Now that we check the
    chdir() error status, some X11 GUI functions (e.g. save file to
    current directory) encounter annoying issues.

  - magick/shear.c (IntegralRotateImage): Limit integral rotate to
    two threads.

  - coders/pnm.c (ReadPNMImage): Limit PNM reader to two threads.

2013-01-01  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - configure.ac (MAGICK\_FEATURES): MinGW static build does not
    build modules so MODULES feature should not be listed as
    supported.  Resolves MinGW test failures.

  - coders/dpx.c (OrientationTypeToDPXOrientation): Return U16 type
    as stored in DPX format.

  - coders/cineon.c: Add support for reading/writing 'orientation'
    setting.

  - coders/mpc.c: Add support for reading/writing 'orientation'
    setting.

  - coders/miff.c: Add support for reading/writing 'orientation'
    setting.

  - Rotate ChangeLog for 2012 and update web page copyright years.
