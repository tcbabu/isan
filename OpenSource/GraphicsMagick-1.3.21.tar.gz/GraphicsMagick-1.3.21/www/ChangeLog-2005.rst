2005-12-31  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - tiff: Update to libtiff 3.8.0. 

2005-12-26  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - NEWS: Updated with latest changes.

  - tiff: Update to libtiff 3.7.4.

2005-12-24  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - lcms: Update to lcms 1.15.

2005-12-19  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/enhance.c (LevelImage): Fix -level command parsing when a
    percent symbol is supplied within the argument rather than at the
    end.

  - magick/utility.c (GetGeometry): Bounds-check geometry string
    length.

2005-12-15  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c: Decided to swap 10-bit subsampled 4:2:2 YCbCr by
    default since this is what practically all sample files I have
    been provided actually do.  Ignore the fact that there is nothing
    in the standard which supports this.

2005-12-10  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/command.c (NormalizeSamplingFactor): Generalized
    subsampling notation parsing support.

2005-12-09  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/command.c (NormalizeSamplingFactor): Add some support for
    normalizing industry-standard subsampling notation (e.g. 4:2:2)
    into GraphicsMagick's unusual notation.

2005-12-06  Ralf Wildenhues  <Ralf.Wildenhues@gmx.de>

  - Updates to use latest development autotools, including
    development libtool 2.0.

2005-12-03  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/image.h: Added some useful macros for accessing
    PixelPacket members in a generic way.

  - coders/dpx.c (ReadDPXImage): For YCbCr with `A` sample, `A`
    sample levels are like Luma.
    (WriteDPXImage): For YCbCr with `A` sample, `A` sample levels are
    like Luma.

2005-12-02  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/tiff.c (RegisterTIFFImage): Report libtiff release
    version rather than ABI version.

2005-11-27  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/resize.c: Revert yesterday's benign-appearing edits since
    they caused a bizzare bug.

2005-11-26  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c (ReadDPXImage): Improve performance when reading
    YCbCr files.  Handle files which use Printing Density on top of
    YCbCr.  Default YCbCr to Rec.709 if the transfer characteristic is
    User Defined.

  - coders/pcd.c (Upsample): Moved Upsample from gem.c to here since
    PCD is the only user and it is not a general purpose function.

2005-11-14  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - VisualMagick/magick/magick\_config.h.in: Remove unnecessary test
    for WIN32.

2005-11-13  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - wand/magick\_compat.c (FormatMagickStringList): MagickExport since this
    function is used by Ch extension.

  - magick/log.c (LogMagickEventList): MagickExport since this
    function is used by Ch extension.

  - magick/utility.c (FormatStringList): MagickExport since this
    function is used by Ch extension.

  - coders/dpx.c (ReadDPXImage): Added support for dpx:swap-samples
    define in order to handle files with Cb and Cr swapped.  Fixed a
    bug in the header reading which caused some valid files to fail to
    read at all.
    (WriteDPXImage): Added support for dpx:swap-samples define in
    order to write files with Cb and Cr swapped.

  - magick/profile.c (ProfileImage): Add support for ICC CMS
    profiles in YCbCr space.

2005-10-10  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/svg.c (ReadSVGImage): Eliminate memory leak.

2005-10-09  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/image.h (Image): Added an orientation member to the Image
    structure to record image orientation for the DPX, and TIFF
    formats. Eventually formats which support IPTC and EXIF embedded
    profiles should be supported by the orientation member as well.

2005-10-08  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - VisualMagick/magick/magick\_types.h.in: Add patch for Ch.

  - magick/command.c (TransmogrifyImage): Complete re-write of
    mogrify file handling.  Former version wrote to a temporary file
    and then moved temporary file to replace original if necessary.
    New version moves an existing writable file to a backup file with
    tilde (`~`) added to end of file name, writes to the final output
    file name, and removes the backup file on success.  The new
    approach satisfies formats which embed the output name in the file
    (e.g. the DPX format) and still works when the output file exists
    and is writeable, but is in non-writeable directory.  The previous
    approach would fail if the output file exists and is writable, but
    the directory is not writeable.

2005-10-01  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c (AttributeToString): Use strncpy rather than
    strlcpy to copy string.  This is important since DPX header
    strings are not null terminated and may need to fill all available
    space.  Certain short header fields like mp.film.manufacturer.id,
    mp.film.type, and mp.perfs.offset were being truncated!

2005-09-25  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/attribute.c (GetImageAttribute): Add more general support
    for retrieving wildcarded attributes so that an identify -format
    specification like `%[dpx:\*]` works as expected.

  - coders/tiff.c (WriteTIFFImage): Transform quality value into zip
    compression quality level similar to what is done for MIFF/MNG/PNG.
    Since default quality value is 75, this means that the default zip
    quality level is 7.

2005-09-24  Peter Wu  <peterw@softintegration.com>

  - Incorporate changes necessary so that GraphicsMagick can work
    with the Ch C/C++ interpreter from SoftIntegration at
    http://www.softintegration.com/.

2005-09-23  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/pixel\_cache.c: Incorporate all functionality from
    cache.c, cache\_view.c, and stream.c so that all private interfaces
    can be fully hidden.  As a result cache.c, cache\_view.c, and
    stream.c are now removed.

2005-09-18  Michal Kowalczuk  <sammael@brzydal.eu.org>

  - coders/gif.c: Free global\_colormap before returning with error.

2005-09-18  Stepan Kasal  <kasal@ucw.cz>

  - Makefile.am (BUILT\_SOURCES): Removed.

  - magick/Makefile.am (MAGICK\_BUILT\_SRCS): Removed, too.

2005-09-12 Glenn Randers-Pehrson <glennrp@glennrp.com>

  - magick/profile.c (ProfileImage):  Free color\_profile->name
    and iptc\_profile->name when destroying the profile.

2005-08-28  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/api.h: Eliminate requirement to include certain system
    headers prior to including <magick/api.h>.

  - utilities/gm.c: Move utility implementation to GMCommand() in
    command.c

2005-08-18  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c: Added support for reading and writing DPX Luma
    files using proper video levels.

  - magick/colorspace.h (enum ColorspaceType): Decided that
    GRAYColorspace should be reserved for full-range grayscale data
    while Rec601LumaColorspace and Rec709LumaColorspace should be for
    video colorspaces.  Therefore, GRAYColorspace is no longer a
    synonym for Rec601LumaColorspace.

  - magick/colorspace.c: Added support for influencing Cineon Log
    colorspace transformations via image attributes.	
    Perform colorspace transformations in floating point rather than
    integer in order to reduce the amount of noise added by
    transform table quantization.

  - coders/psd.c (WritePSDImage): Ensure that output image is 8 or
    16-bits regardless of specific image depth.

  - coders/dpx.c: Added support for planar YCbCr 4:2:2.

2005-08-04  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c (WriteDPXImage): 10 and 12-bit packed data was not
    according to DPX specification.  Added dpx:pixel-endian={lsb|msb}
    to allow the user to specify the endian order of the pixel data in
    case it does (or should not) not match the headers.  Library Of
    Congress format is 10-bit packed data in big-endian format, but is
    marked as little-endian.

2005-08-03  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c: Sample order for filled 10 bit samples matches DPX
    specification (was intentionally reversed).  RGB sample order is
    changed to match DPX specifiation (i.e. BGR rather than RGB).
    Disabled special support for Library Of Congress little-endian
    10-bit packed format.

2005-08-01  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c: Extend all image rows to a 32-bit integer
    boundary.

2005-07-31  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c: Support the little-endian 10-bit packed format as
    used by the Library Of Congress.

2005-07-27  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/jp2.c: Change how Jasper is intialized.  Hopefully
    eliminate memory leak when reading ICC color profile.

  - Overall: Compilation warning elimination with GCC 4.0.1.

  - magick/utility.c (SystemCommand): Always report error status if
    a command fails.

2005-07-26  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - zlib: Updated to version 1.2.3.

  - coders/dpx.c: Use TriangleFilter for scaling chroma.

2005-07-21  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c: Support proper encode and decode of YCbCr video
    levels.

  - magick/colorspace.c: Support Rec709YCbCrColorspace colorspace.

2005-07-05  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/{animate.c, display.c, import.c, xwindow.c}: Rename all
    symbols starting with `X` so that they are prefixed with `Magick`.
    This eases maintenance since it is almost impossible to understand
    code which pretends to be the X11 libraries.  The few programs
    which use the GraphicsMagick `X` functions will need to alter the
    symbol names they use.  Sorry.

  - magick/command.c (DisplayImageCommand): Don't invoke
    XrmDestroyDatabase() to destroy the resource database associated
    with the display since it seems that XCloseDisplay() does this for
    us.

  - magick/image.c (DisplayImages): Don't invoke
    XrmDestroyDatabase() to destroy the resource database associated
    with the display since it seems that XCloseDisplay() does this for
    us.

  - coders/uyvy.c: Enforce image width restrictions.

  - coders/dpx.c: Enforce image width restrictions when subsampling.

2005-07-03  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c: Support reading and writing subsampled CbYCr
    images.  Colorimetery is not right yet.

  - magick/colorspace.h (enum Rec709YCbCrColorspace): New
    enumeration for Rec. 709 YcBCr colorspace.

2005-06-21 Glenn Randers-Pehrson <glennrp@glennrp.com>

  - coders/png.c: Fixed a problem with reading 16-bit PNG images
    using the Q8 quantum depth.

2005-06-19  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c (ReadDPXImage): Add read support for CbYCr at 4:4:4.
    (WriteDPXImage): Add write support for CbYCr at 4:4:4.

2005-06-18  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c (WriteDPXImage): Only preserve source image
    dimension and offset information if image size has not changed.
    If image size has changed, the existing information may become
    invalid.
    (WriteDPXImage): Allow user to assign DPX header attribute values
    using syntax like "-define dpx:mp.frame.position=1000".

2005-06-12  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/fpx.c: Fix compilation problem due to additional
    ExportImagePixelArea parameter.

2005-06-09  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/png.c (WriteMNGImage): Use -define mng:need-cacheoff to
    write a libmng-specific nEED request to disable frame buffering.
    This allows the MNG data to stream without increasing memory
    consumption in the libmng client.

2005-06-07  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c (SMPTEStringToBits): Time code and user bits were
    being displayed in wrong order on little endian CPUs.  Thanks very
    much for bug report from Jason Howard.
    (SMPTEStringToBits): Similar fix for time code and user bits
    string to binary.

2005-06-05  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/miff.c (ReadMIFFImage): Use StringToColorspaceType() to
    parse colorspaces.
  - coders/dpx.c (ReadDPXImage): Change existing
    dpx:source-colorspace define to dpx:colorspace so it is easier to
    remember.

  - coders/cineon.c (ReadCINEONImage): Extract Cineon header
    attributes in DPX compatible form so that it is possible to
    convert Cineon to DPX while losing as little header information as
    possible.  Allow the user to set the existing image colorspace
    using the cineon:colorspace define.

2005-06-01  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/jpeg.c (ReadJPEGImage): Report actual depth of JPEG file
    (8 or 12 bits).

  - coders/cineon.c (ReadCINEONImage): Report depth as 10 bits.

2005-05-26  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c: Retrieve and restore the DPX user defined data
    area.  Make available as a "DPXUSERDATA" attached profile.

2005-05-21  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/meta.c (ReadMETAImage): Fixed reading ICM color profile
    files.  Due to a typo ICM color profiles were being stored as IPTC
    profiles.  This restores proper operation of the -profile option.
    (ReadMETAImage): Fix double free bug.  Hopefully does not result
    in a memory leak in other cases.

2005-05-19  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/image.c (DescribeImage): If the image is DirectClass,
    then don't compute the number of unique colors unless verbose is
    greater than one.  This change is made since computing the number
    of unique colors may take hours for some images.  The handling of
    the -verbose argument is changed so that it is cumulative.
    Specifying -verbose multiple times increases the level of
    verbosity.

2005-05-18  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/nt\_base.c (NTreaddir): Fix write beyond buffer length
    reported in SourceForge issue #1182003.  Only impacts Windows.

2005-05-17  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c (ReadRowSamples): Added necessary masking necessary
    in order to cleanly retrieve DPX 10 bit samples.  Happened to work
    properly without the masking with QuantumDepth=16.

2005-05-16  Tavis Ormandy <taviso@gentoo.org>

  - coders/xwd.c (ReadXWDImage): Fix for infinite loop in the xwd
    decoder when calculating the shift r/g/b values and the mask is
    set to zero.

2005-05-15  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/jp2.c (ReadJP2Image): Return JP2 images as DirectClass
    grayscale rather than PseudoClass.

  - coders/gray.c (ReadGRAYImage): Return GRAY images as DirectClass
    grayscale rather than PseudoClass.

  - coders/dpx.c: Rewrote the DPX pixel reading/writing code yet
    again to obtain up to 2X better performance.  In the process,
    support little-endian pixel storage.

2005-05-11  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c: Added some performance optimizations for reading
    and writing.  Write the motion picture and television headers.

  - magick/colorspace.c (TransformRGBImage): Update image colorspace
    to RGB when transforming from Cineon log space to RGB.

  - coders/dpx.c (WriteDPXImage): Set image date & time field.
    (ReadDPXImage): Retrieve television header SMTPE time code and
    user bits and return them as a formatted string.
    (WriteDPXImage): Fix colorspace mapping logic.  Was converting
    Cineon log to RGB when it shouldn't be.

2005-05-10  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c (WriteDPXImage): Default to big-endian output.

  - magick/delegate.c (InvokePostscriptDelegate): Improved
    Ghostscript API-based error reporting and logging.

  - magick/attribute.c (GenerateEXIFAttribute): Extend EXIF
    knowledge a bit.  Pass more characters from EXIF\_FMT\_BYTE in case
    the byte stream contains nulls.

  - coders/dpx.c: Re-wrote the DPX read/write support in order to
    hopefully surmount problems noticed when testing with files sent
    to me.

  - wand/pixel\_wand.c (PixelSetYellowQuantum): Wrong PixelPacket
    member was being set.  Thanks to Cristy for the heads-up.

  - magick/image.c (SetImageType): Revert change from 2005-03-12.
    Some coders require that when the image is set to Bilevel type,
    that it be PseudoClass.

2005-04-28  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - utilities/tests/convolve.sh: Add a convolution parameter.

2005-04-28 Glenn Randers-Pehrson <glennrp@glennrp.com>

  - magick/command.c: "IsGeometry() test was rejecting valid
    -convolve parameters.  Also, the image returned by ConvolveImage()
    was ignored.

2005-04-25 Glenn Randers-Pehrson <glennrp@glennrp.com>

  - coders/png.c: Initialize several variables to avoid new
    GCC 4.0.0 warnings.

  - coders/pnm.c: Defend against malicious "P7" files that try
    to set the colormap less than 256 bytes (bug fix from ImageMagick)

2005-04-24  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c (WriteDPXImage): Fill out source information
    header.

  - Magick++: Added image leveling methods for Magick++.

2005-04-23  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - NEWS: Update with latest news.

  - magick/blob.c (WriteBlob): Move BlobStream write support to a
    subroutine for easier maintenance.

  - coders/dpx.c (ReadDPXImage): Support retrieving all DPX
    attributes as image attributes.
    (WriteDPXImage): Buffer writes for better performance on some
    platforms.

2005-04-17  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c (WriteDPXImage): Re-write sample marshalling to be
    based on a series of tighter loops.  Results in a small
    performance increase.
    (ReadDPXImage): Re-write sample marshalling to be
    based on a series of tighter loops.  Results in a small
    performance increase.

2005-04-15  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/Xwindow.c (XDelay): Prefer use of select() over poll()
    since it is more portable.  MacOS-X has a poll() but it doesn't
    work right.

2005-04-14  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/magick\_endian.h: Renamed from endian.h in order to avoid
    conflict with system headers.

2005-04-13  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/miff.c (WriteMIFFImage): Normalize image depth to 8/16/32.

  - coders/gray.c (WriteGRAYImage): Normalize image depth to 8/16/32.

  - coders/fits.c (WriteFITSImage): Normalize image depth to 8/16.

  - tests/Makefile.am: Extended read/write tests to include 10, 12,
    and 16-bit original test images.

  - coders/dpx.c (ReadDPXImage): If samples are log encoded, then
    set the image to CineonLogRGBColorspace.
    (WriteDPXImage): If image samples are log encoded, then mark DPX
    file as being log encoded.

  - magick/colorspace.c (TransformRGBImage): Support translation
    from log RGB to linear RGB based on Cineon guidelines.
    (RGBTransformImage): Support translation from linear RGB to log RGB.

  - magick/colorspace.h (enum CineonLogRGBColorspace): New
    enumeration to record that the RGB values are log encoded in a
    2.048 density range as defined for the Cineon Digital Film System.

2005-04-10  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/command.c: Take advantage of ColorspaceTypeToString() and
    StringToColorspaceType() functions in implementation.

  - magick/colorspace.c (RGBTransformImage): Added support for
    converting to Rec 709 grayscale colorspace.
    (ColorspaceTypeToString): New function to translate from
    ColorspaceType enumeration value to a string.
    (StringToColorspaceType): New function to translate from a string
    to a ColorspaceType enumeration value.  \* magick/colorspace.h
    (enum Rec601LumaColorspace): New enumeration to support the Rec
    601 grayscale colorspace.  This is the colorspace previously
    represented by GRAYColorspace. If GRAYColorspace is specified,
    then Rec601LumaColorspace is selected.
    (enum Rec709LumaColorspace): New enumeration to support the Rec
    707 grayscale colorspace.

2005-04-08  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/command.c (IdentifyImageCommand): Use +ping to force
    identify to read the image pixels.

  - magick/constitute.c (PingImage): Intentionally clear
    user/elapsed timer when ping is used on an image since the results
    are misleading.

  - magick/image.c (DescribeImage): Only display pixel read rate if
    the time accumulated is at least the timer's resolution.

  - magick/cache.c (OpenCache): Fix a memory resource leak noticed
    by Stefan v. Wachter <svwa-dev@mnet-online.de>.  This error with
    keeping track of resources may eventually cause GraphicsMagick to
    run slower and slower due to using disk-based images rather than
    memory-based images.

2005-04-07 Glenn Randers-Pehrson <glennrp@glennrp.com>

  - coders/png.c: encoder now accepts image->depth other than 8 and 16.

2005-04-05  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c (WriteDPXImage): First pass at a new SMPTE268M-2003
    DPX writer.

2005-04-02  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/utility.c (AllocateString): Performance enhancement.
    (CloneString): Performance enhancement.
    (ConcatenateString): Performance enhancement.

2005-03-31 Glenn Randers-Pehrson <glennrp@glennrp.com>

  - coders/jpeg.c: revised EOF test.  It was rejecting good image
    files.  Needs more work.

2005-03-30 Glenn Randers-Pehrson <glennrp@glennrp.com>

  - coders/pnm.c (ReadPNMImage): Throw a "Corrupt Image" exception
    if EOF is encountered while reading scanlines in P1, P2, P3, or P4
    formatted images (P5 and P6 were OK).

2005-03-29 Glenn Randers-Pehrson <glennrp@glennrp.com>

  - coders/sgi.c (ReadSGIImage): Throw a "Corrupt Image" exception
    if EOF is encountered while reading scanlines.

2005-03-28 Glenn Randers-Pehrson <glennrp@glennrp.com>

  - coders/jpeg.c (ReadJPEGImage): Throw a "Corrupt Image" exception
    if EOF is encountered while reading scanlines.

  - coders/pcx.c (ReadPCXImage): Throw a "Corrupt Image" exception
    if EOF is encountered while reading pixels.

2005-03-26  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/dpx.c (ReadDPXImage): First pass at a new SMPTE268M-2003
    DPX reader.

  - magick/bit\_stream.h (WordStreamLSBRead): New function to parse
    values from a stream which is defined by 32-bit words.  Values are
    read starting with the least significant bits.

2005-03-23  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/tiff.c (ExtensionTagsInitialize): Fix conditional use of
    TIFFSetTagExtender().

2005-03-20  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/endian.c: Imported libtiff's swab.c since its functions
    are so useful and well-tested.

  - magick/utility.c (FormatSize): Extend to support incredibly
    large sizes.

  - magick/image.c (DescribeImage): Use GetTimerResolution() when
    computing pixels-per-second rate in order to avoid computing
    astronomical rates when the time consumed is too small to measure.

  - magick/timer.c (GetTimerResolution): New function to return the
    timer's resolution.

2005-03-19  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/pdf.c (WritePDFImage): Eliminate cause of annoying
    warning when PDFs are read by Ghostscript 8.5.

2005-03-18  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/nt\_base.h (lt\_dlerror): Needed to provide a mapping to
    NTdlerror().

  - coders/tiff.c (TIFFErrors): Update to make thread safe via
    thread specific data.
    (TIFFWarnings): Update to make thread safe via thread specific
    data.

  - magick/tsd.c (MagickTsdKeyCreate): New function to support
    thread specific data.
    (MagickTsdKeyDelete): ditto
    (MagickTsdSetSpecific): ditto
    (MagickTsdGetSpecific): ditto.

2005-03-17  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/image.c (ReplaceImageColormap): New function to replace
    the image colormap with a user-provided one. Colormap indexes are
    adjusted to point to identical colors in the new colormap.

  - magick/nt\_base.h: Reorganized a bit to cluster code supporting
    similar features in the same area of the header.

  - magick/nt\_base.c: Renamed wrappers for standard functions so
    that they have the prefix `NT`. Macros are used to apply the new
    names. This assures that there will not be conflicts if the library
    is linked with a different package's wrapper functions.

2005-03-15  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/quantize.c (GrayscalePseudoClassImage): Moved to here
    from image.c.  Added support for is\_monochrome.

2005-03-13  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - jp2: Updated Jasper library to version 1.701.0.

  - magick/nt\_base.c (NTGhostscriptFonts): Fixed a coding error
    which was added when strcpy/strcat code was replaced with
    strlcpy/strlcat.  Ghostscript fonts were not being found.

  - magick/constitute.c (ReadImage): Don't attempt to access image
    members if image pointer is null.  Oops!

2005-03-12  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/image.c (SetImageType): Bilevel image is not required to
    be PseudoClass type.

  - coders/mpc.c (WriteMPCImage): Persist is\_monochrome and
    is\_grayscale flags.
    (ReadMPCImage): Restore is\_monochrome and is\_grayscale flags.

  - magick/constitute.c (WriteImage): Extended logging to include
    monochrome and grayscale flags.
    (ReadImage): Extended logging to include monochrome and grayscale
    flags.

  - magick/image.c (DescribeImage): Include the effective pixel I/O
    rate alongside the image read/write time.  This provides an easier
    way to evaluate image read/write performance when looking at
    `identify` or `convert -verbose` output.

  - coders/sun.c (ReadSUNImage): Ensure that pixel length value does
    not overflow for large images.

2005-03-10  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/cache.c (SetImagePixels): Improved documentation.
    (GetImagePixels): Improved documentation.

2005-03-10 Glenn Randers-Pehrson <glennrp@glennrp.com>

  - coders/png.c: Avoid attempting to write indexed PNG when
    a color entry has more than one opacity level.  The PNG format
    supports this but GM's colormap does not, so erroneous files
    were being written.

2005-03-09  Arne Rusek  <zonk@matfyz.cz>

  - magick/attribute.c (GenerateEXIFAttribute): Offset type
    correction to fix loop termination if size\_t type is not `long`.

2005-03-09  Alexander Yaworsky  <yaworsky@users.sourceforge.net>

  - coders/jbig.c (WriteJBIGImage): JBIG was writing an empty output
    file. Apparently libjbig parameters have changed. Setting l0
    parameter of jbg\_enc\_options to zero instead of -1 (like in
    jbigkit's pbmtools) solved the problem.

2005-03-07  Mike Chiarappa  <mikechiarappa@libero.it>

  - BCBMagick\magick\GM\_magick.bpr: Updated to reflect changes since
    last update.

  - BCBMagick\magick\libMagick.bpr: Updated to reflect changes since
    last update.

2005-03-06  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/alpha\_composite.h (AlphaComposite): Moved AlphaComposite
    to new alpha\_composite.h header since it was causing porting
    problems.

  - magick/constitute.h (enum QuantumType): Added CIEYQuantum and
    CIEXYZQuantum quantum import options.

  - coders/tiff.c (ReadTIFFImage): Import LogLuv image data within
    GraphicsMagick (rather than libtiff) so that color resolution is
    not lost.  Results in a small speedup as well.

  - magick/constitute.c (ImportImagePixelArea): Add a speed-up for
    importing bi-level images.  Add support for importing pixels in
    CIE XYZ and CIE Y colorspaces.

  - coders/tiff.c (ReadTIFFImage): Support reading TIFF images which
    fail to properly scale the samples to the sample size (e.g. 12
    bits in a 16-bit sample).
    (WriteTIFFImage): Adjustments to strip-size (rows-per-strip)
    estimation.

  - magick/constitute.c (ExportImagePixelArea): Support exporting
    unsigned samples with values which span only part of the range.
    For example, 12 bit data may be exported within 16 bit samples,
    with a value range of 0 to 4095.
    (ImportImagePixelArea): Support importing unsigned samples with
    values which span only part of the range.

2005-02-26  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/tiff.c (ReadTIFFImage): Support reading TIFF files in
    IEEEFP format.
    (WriteTIFFImage): Support writing TIFF files in IEEEFP format.

  - magick/constitute.c (ExportImagePixelArea): Support exporting
    floating point data.
    (ImportImagePixelArea): Support importing floating point data.

2005-02-26  Albert Chin-A-Young  <china@thewrittenword.com>

  - acinclude.m4 (AC\_CXX\_IOS\_BINARY): Added macro to detect if the
    C++ compiler lacks support for ios::binary.

  - configure.ac: Use  AC\_CXX\_IOS\_BINARY.

2005-02-19  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/tiff.c (ReadTIFFImage): Read grayscale TIFFs as
    DirectClass rather than promoting to PseudoClass.  Fix improper
    multiple repeated "disassociate" operations when reading planar
    images which contain an alpha channel.
    (WriteTIFFImage): Fix improper multiple repeated "associate"
    operations when writing planar images with an alpha channel.

2005-02-16  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - win2k/IMDisplay/IMDisplayView.cpp (DoDisplayImage): Use
    TextureImage to apply background pattern.

  - magick/image.c (TextureImage): Alpha blend the texture onto the
    background if the image has a matte channel.

  - magick/constitute.h (enum QuantumType): Eliminated
    GrayInvertedQuantum and GrayInvertedAlphaQuantum which were added
    since GraphicsMagick 1.1.  Replaced this "inverted" gray
    functionality with the grayscale\_inverted flag in
    ExportPixelAreaOptions and ImportPixelAreaOptions.

  - magick/constitute.c (ExportImagePixelArea): Added an extra
    parameter for passing seldom used options via an
    ExportPixelAreaOptions structure.
    (ImportImagePixelArea): Added an extra parameter for passing
    seldom used options via an ImportPixelAreaOptions structure.
    (ExportPixelAreaOptionsInit): New function to initialize the
    ExportPixelAreaOptions structure with defaults.
    (ImportPixelAreaOptionsInit): New function to intialize the
    ImportPixelAreaOptions structure with defaults.

  - coders/jpeg.c (WriteJPEGImage): Don't use jpeglib private
    BITS\_IN\_JSAMPLE definition to select JPEG bit depth.

  - coders/tiff.c (ReadTIFFImage): Support using -define
    tiff:alpha={unspecified|associated|unassociated} to specify the
    alpha channel type in case the alpha channel is marked
    incorrectly.
    Properly read associated alpha images.
    (WriteTIFFImage): Support using -define
    tiff:alpha={unspecified|associated|unassociated} to override the
    alpha channel type.
    Properly write associated alpha images by default.

2005-02-02  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/tiff.c (WritePTIFImage): Ensure that pyramid image frames
    are the same type as the original image.
    (WriteTIFFImage): Added support for writing tiled TIFF.

2005-01-31  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/render.c (TraceBezier): Avoid probable bug under Visual
    C++ 7.0 or later due to the argument to pow not being promoted to
    double.

2005-01-30  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/tiff.c (WriteTIFFImage): Re-wrote TIFF writing code.

  - magick/image.h (MaxValueGivenBits): Renamed MaxRGBGivenBits
    macro to MaxValueGivenBits.

  - magick/constitute.h (enum QuantumType): Added UndefinedQuantum.

  - magick/static.c (RegisterStaticModules): Support compiling
    without PNG.

2005-01-29  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/color.c (IsPaletteImage): Fix memory leak reported by
    Stefan v. Wachter <svwa-dev@mnet-online.de>.

  - magick/Makefile.am (MAGICK\_INCLUDE\_HDRS): Needed to install
    magick/operator.h.

  - coders/tiff.c (ReadTIFFImage): Re-wrote TIFF reading code again
    for more flexibility and performance.

2005-01-17  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - configure.ac: Remove --disable-lzw option and HasLZW define.
    LZW support is always enabled now.

2005-01-16  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/tga.c (WriteTGAImage): Incorporated patch from Stefan
    v. Wachter to enable writing grayscale images as well as adding
    more image type option smarts.

  - coders/psd.c (ReadPSDImage): Fix stack overflow vulnerability
    reported by Andrei Nigmatulin. See http://lwn.net/Articles/119713/
    for details.

2005-01-14  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - win2k/IMDisplay/IMDisplayDoc.cpp (DoReadImage): Ensure that image
    is in RGB color space after being read since this is what Windows
    expects.

2005-01-13  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/tiff.c (ReadTIFFImage): Handle extra samples in scanline
    TIFFs.

2005-01-09  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - magick/image.c (DescribeImage): Report statistics for a virtual
    gray channel for grayscale images rather than discrete red, green,
    and blue.

  - PerlMagick/Makefile.nt: JNG and JP2 to test list.

  - configure.ac: Changed --without-fpx to --with-fpx due to
    decision to default FlashPIX to `no`.  FlashPIX library is not
    very portable and is only known to work properly under SPARC
    Solaris and Windows.

  - NEWS: Updated with latest news.

  - lcms: Updated to LCMS 1.14.

2005-01-08  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/jp2.c (ReadJP2Image): Handle images in YCBCR colorspace.
    (ReadJP2Image): Retrieve and store an ICC ICM color profile if
    present.

  - PerlMagick/t/tiff/read.t: Added test for reading truecolor
    planar TIFF image.
    Added test for reading 32-bit TrueColor TIFF image.
    Added test for reading 32-bit grayscale TIFF image.

  - coders/tiff.c (ReadTIFFImage): Fixed stripped TIFF reader.

2005-01-04  Bob Friesenhahn  <bfriesen@simple.dallas.tx.us>

  - coders/tiff.c (WriteTIFFImage): Only set TIFFTAG\_PREDICTOR to 2
    for bits-per-sample values that libtiff supports.

